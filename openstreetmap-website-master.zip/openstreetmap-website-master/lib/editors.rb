module Editors
  ALL_EDITORS = %w(potlatch potlatch2 id remote).freeze
  RECOMMENDED_EDITORS = %w(id potlatch2 remote).freeze
end
