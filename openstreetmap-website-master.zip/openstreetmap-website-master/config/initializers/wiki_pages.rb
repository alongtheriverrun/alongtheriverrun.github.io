WIKI_PAGES = YAML.load_file("#{Rails.root}/config/wiki_pages.yml")
